import { useEffect, useState } from 'react';

export type Route = 'home' | 'gallery';

export function useRouter() {
  const [route, setRoute] = useState<Route>(() => {
    const hash = window.location.hash;
    if (hash === '#/gallery') return 'gallery';
    return 'home';
  });

  useEffect(() => {
    const onHashChange = () => {
      const hash = window.location.hash;
      if (hash === '#/gallery') {
        setRoute('gallery');
      } else {
        setRoute('home');
      }
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (to: Route) => {
    if (to === 'gallery') {
      window.location.hash = '#/gallery';
    } else {
      window.location.hash = '';
      setRoute('home');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return { route, navigate };
}
