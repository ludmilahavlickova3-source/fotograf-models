import { useEffect, useState } from 'react';
import { aboutImage, featuredImage, quotes, stats } from '@/data/photos';
import { useReveal } from '@/hooks/useReveal';
import { useParallax } from '@/hooks/useParallax';

function AnimatedCounter({
  value,
  suffix,
  visible,
}: {
  value: number;
  suffix: string;
  visible: boolean;
}) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!visible) return;
    let frame = 0;
    const duration = 2000;
    const start = performance.now();

    const animate = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * value));
      if (progress < 1) {
        frame = requestAnimationFrame(animate);
      }
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [value, visible]);

  return (
    <span className="font-display tabular-nums">
      {count}
      {suffix}
    </span>
  );
}

export default function About() {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const parallax = useParallax(0.15);
  const [quoteIndex, setQuoteIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setQuoteIndex((prev) => (prev + 1) % quotes.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="about" className="relative py-20 md:py-28 px-6 md:px-12 overflow-hidden">
      <div
        ref={ref}
        className={`max-w-[1600px] mx-auto reveal ${visible ? 'visible' : ''}`}
      >
        {/* Rotating quote over featured image */}
        <div className="relative h-[50vh] md:h-[65vh] overflow-hidden rounded-3xl mb-16 clip-reveal">
          <div className={visible ? 'visible' : ''}>
            <div
              className="w-full h-full"
              style={{ transform: `translateY(${parallax * 0.2}px) scale(1.15)` }}
            >
              <img
                src={featuredImage}
                alt="Featured"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-cream-950/80 via-cream-950/30 to-cream-950/10" />
          <div className="absolute bottom-0 left-0 right-0 p-8 md:p-14">
            {quotes.map((q, i) => (
              <div
                key={i}
                className={`transition-all duration-1000 ${
                  i === quoteIndex
                    ? 'opacity-100 translate-y-0'
                    : 'opacity-0 translate-y-8 absolute pointer-events-none'
                }`}
              >
                <p className="font-display italic text-2xl md:text-4xl lg:text-5xl text-cream-50 leading-tight max-w-3xl text-balance">
                  „{q.text}"
                </p>
                <p className="mt-3 text-[10px] tracking-[0.35em] uppercase text-gold-300">
                  {q.author}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* About content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Image column */}
          <div className="lg:col-span-5 lg:sticky lg:top-28">
            <div className={`relative clip-reveal-left ${visible ? 'visible' : ''}`}>
              <div className="relative overflow-hidden rounded-3xl">
                <img
                  src={aboutImage}
                  alt="Robert Rot"
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-cream-950/30 to-transparent" />
              </div>
              <div className="absolute -top-5 -right-5 glass rounded-2xl px-5 py-3 shadow-xl shadow-cream-300/30">
                <p className="font-display text-3xl text-gold-600">20</p>
                <p className="text-[9px] tracking-[0.3em] uppercase text-cream-700">
                  let
                </p>
              </div>
            </div>
          </div>

          {/* Text column */}
          <div className="lg:col-span-7 lg:pt-8">
            <div className={`reveal reveal-delay-1 ${visible ? 'visible' : ''}`}>
              <p className="section-label mb-3">O mně</p>
              <h2 className="font-display text-4xl md:text-6xl text-cream-950 mb-6 leading-tight">
                Robert <span className="italic text-gold-600">Rot</span>
              </h2>
            </div>

            <div className={`reveal reveal-delay-2 ${visible ? 'visible' : ''}`}>
              <p className="text-cream-700 font-light leading-relaxed mb-4 text-lg text-pretty">
                Jmenuji se Robert Rot a fotím lidi už dvacet let. Začal jsem v Praze
                s borrowed camera a jedním objektivem, kterým jsem neuměl ani točit
                manuálně. Dnes dělám portréty, editorial a komerční práci, ale pořád
                mě baví nejvíc jedno. Sednout si s někým, který přede mnou nikdy
                nefotil, a zjistit, co v něm je.
              </p>
              <p className="text-cream-700 font-light leading-relaxed mb-4 text-pretty">
                Nemám rád slovo modelka. Preferuji člověk, který stojí přede mnou.
                Někdo přijde s přesnou představou, jiný neví, kam dát ruce. Obojí je
                v pořádku. Moje práce je udělat to, aby jste si po chvíli uvědomili,
                že už nestojíte na place. Že si povídáme. A že fotoaparát je jen
                věc, co tam někde leží.
              </p>
              <p className="text-cream-700 font-light leading-relaxed mb-4 text-pretty">
                Fotím převážně s přírodním světlem. Někdy si půjčím studio, ale většinou
                mě mrzí, když tam musím zapnout blesky. Zlatá hodina je prostě zlatá
                hodina. Něco lepšího člověk nevymyslí, i když by stál v dešti na betonovém
                parkovišti. Mám rád, když se fotka trochu kazí. Trochu zrní, trochu se
                třese. To je totiž ten moment, kdy přestává být vizualizací a stává se
                vzpomínkou.
              </p>
              <p className="text-cream-700 font-light leading-relaxed mb-10 text-pretty">
                Pracuji s agenturou Public Revelation, pro kterou dělám většinu
                komerčních zakázek. Pokud chcete portrét, editorial nebo prostě
                fotky, na které se budete ráda dívat za pět let, napište mi.
                Rád se domluvíme.
              </p>
            </div>

            {/* Stats */}
            <div
              className={`grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 reveal reveal-delay-3 ${
                visible ? 'visible' : ''
              }`}
            >
              {stats.map((stat, i) => (
                <div
                  key={i}
                  className="glass rounded-2xl p-5 text-center shadow-lg shadow-cream-300/20"
                >
                  <p className="font-display text-3xl md:text-4xl text-gold-600">
                    <AnimatedCounter
                      value={stat.value}
                      suffix={stat.suffix}
                      visible={visible}
                    />
                  </p>
                  <p className="text-[9px] tracking-[0.25em] uppercase text-cream-600 mt-1">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
