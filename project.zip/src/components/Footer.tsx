import { useEffect, useState } from 'react';
import { ArrowUp } from 'lucide-react';
import { marqueeWords } from '@/data/photos';

export default function Footer() {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <footer className="relative pt-16 pb-8 px-6 md:px-12 overflow-hidden bg-cream-100/50 border-t border-cream-200">
      <div className="max-w-[1600px] mx-auto mb-10 overflow-hidden">
        <h2 className="font-display text-[18vw] md:text-[14vw] leading-none text-cream-300 select-none whitespace-nowrap text-center">
          Robert Rot
        </h2>
      </div>

      <div className="max-w-[1600px] mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <p className="font-display text-xl text-cream-950">
            Robert <span className="text-gold-600 italic">Rot</span>
          </p>
          <p className="text-[10px] tracking-[0.25em] uppercase text-cream-500 mt-1">
            Fotografie · Praha
          </p>
        </div>

        <div className="hidden md:flex items-center gap-5 text-[10px] tracking-[0.3em] uppercase text-cream-500">
          {marqueeWords.slice(0, 5).map((w, i) => (
            <span key={i} className="flex items-center gap-5">
              {w}
              {i < 4 && <span className="text-gold-400/40">·</span>}
            </span>
          ))}
        </div>

        <div className="flex items-center gap-6">
          <p className="text-[10px] text-cream-500 tracking-wide">
            © {new Date().getFullYear()} Robert Rot
          </p>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className={`flex items-center gap-2 text-[10px] tracking-[0.25em] uppercase text-cream-600 hover:text-cream-950 transition-all duration-500 ${
              showTop ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
          >
            Nahoru
            <ArrowUp size={14} />
          </button>
        </div>
      </div>
    </footer>
  );
}
