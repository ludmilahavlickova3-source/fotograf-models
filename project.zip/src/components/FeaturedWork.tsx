import { splitLeftImage, splitRightImage } from '@/data/photos';
import { useReveal } from '@/hooks/useReveal';
import { useParallax } from '@/hooks/useParallax';

export default function FeaturedWork() {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const parallax = useParallax(0.12);

  return (
    <section className="relative py-20 md:py-28 px-6 md:px-12 overflow-hidden">
      <div
        ref={ref}
        className={`max-w-[1600px] mx-auto reveal ${visible ? 'visible' : ''}`}
      >
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <p className="section-label mb-3">Dvě tváře</p>
            <h2 className="font-display text-4xl md:text-6xl text-cream-950 tracking-tight">
              Vedle sebe
            </h2>
          </div>
          <p className="text-cream-600 max-w-sm font-light leading-relaxed">
            Dva portréty najednou. Kontrast, který by sám o sobě nefungoval.
          </p>
        </div>

        {/* Split screen */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 relative">
          {/* Left panel */}
          <div
            className={`relative h-[60vh] md:h-[80vh] overflow-hidden rounded-3xl clip-reveal ${
              visible ? 'visible' : ''
            }`}
          >
            <div
              className="absolute inset-0"
              style={{ transform: `translateY(${parallax * -0.3}px) scale(1.1)` }}
            >
              <img
                src={splitLeftImage}
                alt="Sophistication"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-cream-950/50 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 p-6 md:p-10">
              <p className="text-[9px] tracking-[0.35em] uppercase text-gold-300 mb-2">
                Editorial · 2024
              </p>
              <h3 className="font-display text-3xl md:text-5xl text-cream-50">
                Ticho
              </h3>
              <p className="mt-2 text-cream-200 max-w-xs font-light leading-relaxed text-sm">
                Černé šaty, čistá stěna. Cítila se dobře a to je na snímku vidět.
              </p>
            </div>
          </div>

          {/* Right panel */}
          <div
            className={`relative h-[60vh] md:h-[80vh] overflow-hidden rounded-3xl clip-reveal-right md:mt-12 ${
              visible ? 'visible' : ''
            }`}
            style={{ transitionDelay: '0.3s' }}
          >
            <div
              className="absolute inset-0"
              style={{ transform: `translateY(${parallax * 0.3}px) scale(1.1)` }}
            >
              <img
                src={splitRightImage}
                alt="Pohled"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-cream-950/50 via-transparent to-transparent" />
            <div className="absolute bottom-0 right-0 p-6 md:p-10 text-right">
              <p className="text-[9px] tracking-[0.35em] uppercase text-gold-300 mb-2">
                Detail · 2023
              </p>
              <h3 className="font-display text-3xl md:text-5xl text-cream-50">
                Pohled
              </h3>
              <p className="mt-2 text-cream-200 max-w-xs font-light leading-relaxed text-sm ml-auto">
                Šedé oči, žádný makeup. Fotka vznikla mezi dvěma záběry.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
