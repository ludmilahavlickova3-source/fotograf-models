import { useEffect, useState } from 'react';

export default function Loader({ onDone }: { onDone?: () => void }) {
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let current = 0;
    const interval = setInterval(() => {
      current += Math.random() * 7 + 2;
      if (current >= 100) {
        current = 100;
        clearInterval(interval);
        setTimeout(() => {
          setDone(true);
          onDone?.();
        }, 500);
      }
      setProgress(Math.floor(current));
    }, 70);
    return () => clearInterval(interval);
  }, [onDone]);

  return (
    <div
      className={`fixed inset-0 z-[10000] bg-cream-100 flex flex-col items-center justify-center transition-all duration-1000 ${
        done ? 'opacity-0 -translate-y-full pointer-events-none' : 'opacity-100'
      }`}
    >
      <div className="overflow-hidden mb-6">
        <h1
          className="font-display text-5xl md:text-7xl text-cream-950 tracking-tight"
          style={{ animation: 'fadeUp 1s cubic-bezier(0.16,1,0.3,1) 0.2s both' }}
        >
          Robert <span className="text-gold-600 italic">Rot</span> Fotograf
        </h1>
      </div>

      <p
        className="text-[10px] tracking-[0.5em] uppercase text-cream-500 mb-10"
        style={{ animation: 'fadeIn 1s ease-out 0.5s both' }}
      >
        Fotografie
      </p>

      <div className="w-48 md:w-64 h-px bg-cream-300 relative overflow-hidden">
        <div
          className="absolute top-0 left-0 h-full bg-gold-500"
          style={{ width: `${progress}%`, transition: 'width 0.1s linear' }}
        />
      </div>

      <p className="mt-4 font-display text-sm text-cream-600 tabular-nums">
        {progress}
      </p>
    </div>
  );
}
