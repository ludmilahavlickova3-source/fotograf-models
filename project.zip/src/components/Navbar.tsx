import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import type { Route } from '@/hooks/useRouter';

interface NavbarProps {
  route: Route;
  onNavigate: (to: Route) => void;
}

export default function Navbar({ route, onNavigate }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (to: Route, section?: string) => {
    if (to === 'home' && section) {
      onNavigate('home');
      setTimeout(() => {
        document.querySelector(section)?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      onNavigate(to);
    }
    setMenuOpen(false);
  };

  const links: { label: string; action: () => void }[] = [
    { label: 'Galerie', action: () => handleNav('gallery') },
    { label: 'O mně', action: () => handleNav('home', '#about') },
    { label: 'Kontakt', action: () => handleNav('home', '#contact') },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
          scrolled || route === 'gallery' ? 'py-3' : 'py-6'
        }`}
      >
        <nav
          className={`max-w-[1600px] mx-4 md:mx-auto px-6 md:px-12 py-3 flex items-center justify-between rounded-full transition-all duration-700 ${
            scrolled || route === 'gallery'
              ? 'glass shadow-lg shadow-cream-300/20'
              : 'bg-transparent'
          }`}
        >
          <button
            onClick={() => handleNav('home')}
            className="font-display text-xl md:text-2xl tracking-tight text-cream-950 transition-opacity duration-300 hover:opacity-70"
          >
            Robert <span className="text-gold-600 italic">Rot</span>
          </button>

          <div className="hidden md:flex items-center gap-10">
            {links.map((link) => (
              <button
                key={link.label}
                onClick={link.action}
                className="nav-link"
              >
                {link.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => setMenuOpen(true)}
            className="md:hidden text-cream-900 p-2"
            aria-label="Otevřít menu"
          >
            <Menu size={22} />
          </button>
        </nav>
      </header>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-[60] bg-cream-100 transition-all duration-500 ${
          menuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="flex justify-end p-6">
          <button
            onClick={() => setMenuOpen(false)}
            className="text-cream-900 p-2"
            aria-label="Zavřít menu"
          >
            <X size={28} />
          </button>
        </div>
        <div className="flex flex-col items-center justify-center h-full -mt-20 gap-8">
          {links.map((link, i) => (
            <button
              key={link.label}
              onClick={link.action}
              className="font-display text-4xl text-cream-900 transition-colors duration-300 hover:text-gold-600"
              style={{
                animation: menuOpen
                  ? `fadeUp 0.6s ease-out ${i * 0.1}s both`
                  : 'none',
              }}
            >
              {link.label}
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
