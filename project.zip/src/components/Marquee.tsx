import { marqueeWords } from '@/data/photos';

export default function Marquee() {
  const items = [...marqueeWords, ...marqueeWords];

  return (
    <div className="relative py-6 md:py-8 overflow-hidden border-y border-cream-200 bg-cream-100/50">
      <div className="marquee-track">
        {items.map((word, i) => (
          <span
            key={i}
            className="font-display text-4xl md:text-6xl text-cream-400 hover:text-gold-500 transition-colors duration-500 mx-6 whitespace-nowrap italic"
          >
            {word}
            <span className="text-gold-400/40 not-italic mx-3">·</span>
          </span>
        ))}
      </div>
    </div>
  );
}
