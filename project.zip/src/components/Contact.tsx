import { useState } from 'react';
import { useReveal } from '@/hooks/useReveal';
import { useParallax } from '@/hooks/useParallax';
import { landscapeImage2 } from '@/data/photos';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

export default function Contact() {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const parallax = useParallax(0.12);
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setForm({ name: '', email: '', message: '' });
    }, 4000);
  };

  const contactItems = [
    { icon: Mail, label: 'E-mail', value: 'robert@public-revelation.com', href: 'mailto:robert@public-revelation.com' },
    { icon: Phone, label: 'Telefon', value: '775 202 771', href: 'tel:+420775202771' },
    { icon: MapPin, label: 'Studio', value: 'Praha', href: null },
  ];

  return (
    <section id="contact" className="relative py-20 md:py-28 px-6 md:px-12 overflow-hidden">
      <div
        className="absolute inset-0 z-0"
        style={{ transform: `translateY(${parallax * 0.2}px)` }}
      >
        <img
          src={landscapeImage2}
          alt=""
          className="w-full h-full object-cover opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-cream-50 via-cream-50/80 to-cream-50" />
      </div>

      <div
        ref={ref}
        className={`relative z-10 max-w-[1600px] mx-auto reveal ${visible ? 'visible' : ''}`}
      >
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <p className="section-label mb-3">Spojte se se mnou</p>
            <h2 className="font-display text-5xl md:text-7xl text-cream-950 tracking-tight">
              Kontakt
            </h2>
          </div>
          <p className="text-cream-600 max-w-sm font-light leading-relaxed">
            Chcete se domluvit na focení? Napište mi nebo zavolejte.
            Obyčejný e-mail stačí, hned si najdeme termín.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-12">
          {/* Contact info */}
          <div className={`reveal reveal-delay-1 ${visible ? 'visible' : ''}`}>
            <div className="space-y-3">
              {contactItems.map((item, i) => (
                <div
                  key={i}
                  className="glass rounded-2xl p-5 flex items-center gap-4 group hover:shadow-xl hover:shadow-cream-300/30 transition-all duration-500"
                  style={{
                    opacity: visible ? 1 : 0,
                    transform: visible ? 'translateY(0)' : 'translateY(20px)',
                    transition: 'opacity 0.8s ease, transform 0.8s ease',
                    transitionDelay: `${0.2 + i * 0.1}s`,
                  }}
                >
                  <div className="p-3 rounded-xl bg-cream-100 group-hover:bg-gold-100 transition-colors duration-500">
                    <item.icon
                      size={20}
                      className="text-cream-700 group-hover:text-gold-600 transition-colors duration-500"
                    />
                  </div>
                  <div>
                    <p className="text-[9px] tracking-[0.25em] uppercase text-cream-500 mb-1">
                      {item.label}
                    </p>
                    {item.href ? (
                      <a
                        href={item.href}
                        className="text-cream-900 hover:text-gold-600 transition-colors duration-300 font-light"
                      >
                        {item.value}
                      </a>
                    ) : (
                      <p className="text-cream-900 font-light">{item.value}</p>
                    )}
                  </div>
                </div>
              ))}

              {/* X (Twitter) link card */}
              <a
                href="https://x.com/PRmodelagency"
                target="_blank"
                rel="noopener noreferrer"
                className="glass rounded-2xl p-5 flex items-center gap-4 group hover:shadow-xl hover:shadow-cream-300/30 transition-all duration-500"
                style={{
                  opacity: visible ? 1 : 0,
                  transform: visible ? 'translateY(0)' : 'translateY(20px)',
                  transition: 'opacity 0.8s ease, transform 0.8s ease',
                  transitionDelay: '0.5s',
                }}
              >
                <div className="p-3 rounded-xl bg-cream-100 group-hover:bg-gold-100 transition-colors duration-500">
                  <svg
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="text-cream-700 group-hover:text-gold-600 transition-colors duration-500"
                  >
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                </div>
                <div>
                  <p className="text-[9px] tracking-[0.25em] uppercase text-cream-500 mb-1">
                    X
                  </p>
                  <p className="text-cream-900 group-hover:text-gold-600 transition-colors duration-300 font-light">
                    @PRmodelagency
                  </p>
                </div>
              </a>
            </div>
          </div>

          {/* Contact form */}
          <div className={`reveal reveal-delay-2 ${visible ? 'visible' : ''}`}>
            <form
              onSubmit={handleSubmit}
              className="glass rounded-3xl p-8 md:p-10 space-y-6 shadow-xl shadow-cream-300/20"
            >
              <div>
                <label className="block text-[10px] tracking-[0.25em] uppercase text-cream-600 mb-2">
                  Jméno
                </label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full bg-cream-50/50 border-b border-cream-300 py-3 text-cream-950 font-light focus:border-gold-500 focus:outline-none transition-colors duration-300 placeholder:text-cream-400 rounded-t-lg"
                  placeholder="Jak se jmenujete"
                />
              </div>
              <div>
                <label className="block text-[10px] tracking-[0.25em] uppercase text-cream-600 mb-2">
                  E-mail
                </label>
                <input
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full bg-cream-50/50 border-b border-cream-300 py-3 text-cream-950 font-light focus:border-gold-500 focus:outline-none transition-colors duration-300 placeholder:text-cream-400 rounded-t-lg"
                  placeholder="vas@email.cz"
                />
              </div>
              <div>
                <label className="block text-[10px] tracking-[0.25em] uppercase text-cream-600 mb-2">
                  Zpráva
                </label>
                <textarea
                  required
                  rows={4}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full bg-cream-50/50 border-b border-cream-300 py-3 text-cream-950 font-light focus:border-gold-500 focus:outline-none transition-colors duration-300 placeholder:text-cream-400 resize-none rounded-t-lg"
                  placeholder="Napište mi, o co vám jde"
                />
              </div>
              <button
                type="submit"
                disabled={sent}
                className={`flex items-center gap-3 px-8 py-4 text-[10px] tracking-[0.3em] uppercase rounded-full transition-all duration-500 group ${
                  sent
                    ? 'bg-sage-200 text-sage-800 border border-sage-400'
                    : 'bg-cream-950 text-cream-50 hover:bg-gold-600'
                }`}
              >
                {sent ? (
                  <>Odesláno</>
                ) : (
                  <>
                    Odeslat
                    <Send
                      size={16}
                      className="group-hover:translate-x-1 transition-transform duration-300"
                    />
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
