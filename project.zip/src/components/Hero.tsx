import { useEffect, useState } from 'react';
import { heroImages } from '@/data/photos';
import { useParallax } from '@/hooks/useParallax';
import { ArrowDown } from 'lucide-react';

export default function Hero() {
  const [current, setCurrent] = useState(0);
  const [loaded, setLoaded] = useState<boolean[]>(() =>
    heroImages.map(() => false)
  );
  const parallax = useParallax(0.3);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="top" className="relative min-h-screen w-full overflow-hidden pt-24 pb-12">
      <div className="absolute top-20 -left-20 w-96 h-96 rounded-full bg-gold-200/30 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-20 -right-20 w-96 h-96 rounded-full bg-rose-200/20 blur-[120px] pointer-events-none" />

      <div className="relative z-10 max-w-[1600px] mx-auto px-6 md:px-12 h-full">
        <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-16 min-h-[calc(100vh-10rem)]">
          <div className="flex-1 flex flex-col justify-center">
            <div
              className="overflow-hidden mb-6"
              style={{ animation: 'fadeIn 1s ease-out 0.3s both' }}
            >
              <p className="section-label">Fotografie · Praha</p>
            </div>

            <h1
              className="font-display text-6xl sm:text-7xl md:text-8xl lg:text-9xl text-cream-950 leading-[0.95] tracking-tight text-balance"
              style={{ animation: 'fadeUp 1s cubic-bezier(0.16,1,0.3,1) 0.5s both' }}
            >
              Obraz
              <br />
              <span className="italic text-gold-600">ženy</span>{' '}
              <span
                className="text-mask"
                style={{
                  backgroundImage: `url(${heroImages[current]})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                }}
              >
                ve světle
              </span>
            </h1>

            <p
              className="mt-8 text-base md:text-lg text-cream-700 max-w-md font-light leading-relaxed text-pretty"
              style={{ animation: 'fadeUp 1s ease-out 0.8s both' }}
            >
              Fotím ženy tak, jak je vidím. Bez zbytečné pózy. Bez přetvářky.
              Hledám moment, kdy přestanete hrát a budete prostě vy.
            </p>

            <a
              href="#gallery"
              className="mt-10 inline-flex items-center gap-3 text-[11px] tracking-[0.3em] uppercase text-cream-800 hover:text-gold-600 transition-colors duration-500 group w-fit"
              style={{ animation: 'fadeUp 1s ease-out 1.1s both' }}
            >
              Podívat se na práci
              <ArrowDown
                size={16}
                className="group-hover:translate-y-1 transition-transform duration-300"
              />
            </a>
          </div>

          <div className="flex-1 relative w-full h-[50vh] lg:h-[80vh]">
            <div
              className="absolute inset-0"
              style={{ transform: `translateY(${parallax * 0.15}px)` }}
            >
              {heroImages.map((src, i) => (
                <div
                  key={i}
                  className={`absolute inset-0 transition-all duration-[1500ms] ease-out ${
                    i === current
                      ? 'opacity-100 scale-100'
                      : 'opacity-0 scale-105'
                  }`}
                >
                  <div
                    className={`w-full h-full ${
                      loaded[i] ? '' : 'img-shimmer'
                    } animate-slow-zoom rounded-3xl overflow-hidden`}
                    style={{ animationDelay: `${i * 2}s` }}
                  >
                    <img
                      src={src}
                      alt=""
                      className={`w-full h-full object-cover ${
                        loaded[i] ? 'opacity-100' : 'opacity-0'
                      } transition-opacity duration-1000`}
                      onLoad={() =>
                        setLoaded((prev) => {
                          const next = [...prev];
                          next[i] = true;
                          return next;
                        })
                      }
                    />
                  </div>
                </div>
              ))}
            </div>

            <div
              className="absolute bottom-6 left-6 glass rounded-2xl p-5 max-w-[220px] shadow-xl shadow-cream-300/30"
              style={{ animation: 'fadeUp 1s ease-out 1.3s both' }}
            >
              <p className="text-[9px] tracking-[0.3em] uppercase text-gold-600 mb-1">
                Snímek
              </p>
              <p className="font-display text-xl text-cream-950">
                {String(current + 1).padStart(2, '0')} / {String(heroImages.length).padStart(2, '0')}
              </p>
              <div className="mt-3 flex gap-1.5">
                {heroImages.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrent(i)}
                    className={`h-1 rounded-full transition-all duration-500 ${
                      i === current
                        ? 'w-8 bg-gold-500'
                        : 'w-4 bg-cream-400'
                    }`}
                    aria-label={`Snímek ${i + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
