import { useState, useMemo } from 'react';
import { photos, type Photo } from '@/data/photos';
import { useReveal } from '@/hooks/useReveal';
import { X, ChevronLeft, ChevronRight, Calendar, Tag, ArrowRight } from 'lucide-react';

const bentoSpans = [
  'col-span-2 row-span-2',
  'col-span-1 row-span-1',
  'col-span-1 row-span-1',
  'col-span-1 row-span-2',
  'col-span-2 row-span-1',
  'col-span-1 row-span-1',
];

export default function Gallery({ onNavigateGallery }: { onNavigateGallery?: () => void }) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const [lightbox, setLightbox] = useState<number | null>(null);

  const preview = photos.slice(0, 6);

  const openLightbox = (index: number) => setLightbox(index);
  const closeLightbox = () => setLightbox(null);
  const nextPhoto = () =>
    setLightbox((prev) =>
      prev === null ? null : (prev + 1) % preview.length
    );
  const prevPhoto = () =>
    setLightbox((prev) =>
      prev === null ? null : (prev - 1 + preview.length) % preview.length
    );

  const currentPhoto: Photo | null =
    lightbox !== null ? preview[lightbox] : null;

  return (
    <section id="gallery" className="relative py-20 md:py-28 px-6 md:px-12">
      <div
        ref={ref}
        className={`max-w-[1600px] mx-auto reveal ${visible ? 'visible' : ''}`}
      >
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <p className="section-label mb-3">Portfolio</p>
            <h2 className="font-display text-5xl md:text-7xl text-cream-950 tracking-tight">
              Galerie
            </h2>
          </div>
          <p className="text-cream-600 max-w-sm font-light leading-relaxed">
            Výběr šesti fotek. Celá sbírka je větší, tohle je ochutnávka.
          </p>
        </div>

        {/* Bento grid — 6 photos */}
        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[200px] md:auto-rows-[250px] gap-3 md:gap-4">
          {preview.map((photo, i) => (
            <div
              key={photo.id}
              onClick={() => openLightbox(i)}
              className={`gallery-card group ${bentoSpans[i % bentoSpans.length]} ${
                visible ? 'reveal visible' : 'reveal'
              }`}
              style={{ transitionDelay: `${(i % 8) * 0.08}s` }}
            >
              <div className={`w-full h-full ${!visible ? 'img-shimmer' : ''}`}>
                <img
                  src={photo.src}
                  alt={photo.title}
                  loading="lazy"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="overlay" />
              <div className="meta">
                <p className="text-[9px] tracking-[0.3em] uppercase text-gold-300 mb-1">
                  {photo.category} · {photo.year}
                </p>
                <h3 className="font-display text-xl md:text-2xl text-cream-50">
                  {photo.title}
                </h3>
              </div>
              <div className="absolute top-3 right-3 font-display text-xs text-cream-50/0 group-hover:text-cream-50/50 transition-all duration-500">
                {String(i + 1).padStart(2, '0')}
              </div>
            </div>
          ))}
        </div>

        {/* CTA to full gallery */}
        <div className="mt-10 text-center">
          <button
            onClick={onNavigateGallery}
            className="inline-flex items-center gap-3 px-8 py-4 text-[10px] tracking-[0.3em] uppercase rounded-full bg-cream-950 text-cream-50 hover:bg-gold-600 transition-all duration-500 group"
          >
            Celá galerie
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-300" />
          </button>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox !== null && currentPhoto && (
        <div
          className="fixed inset-0 z-[100] lightbox-backdrop bg-cream-950/90 flex items-center justify-center p-4 md:p-12"
          style={{ animation: 'fadeIn 0.4s ease-out forwards' }}
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 text-cream-200 hover:text-cream-50 transition-colors p-2 z-10"
            aria-label="Zavřít"
          >
            <X size={32} />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              prevPhoto();
            }}
            className="absolute left-4 md:left-8 text-cream-200 hover:text-cream-50 transition-colors p-2 z-10"
            aria-label="Předchozí"
          >
            <ChevronLeft size={40} />
          </button>

          <div
            className="max-w-4xl w-full flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
            style={{ animation: 'scaleIn 0.5s ease-out forwards' }}
          >
            <img
              src={currentPhoto.src}
              alt={currentPhoto.title}
              className="max-h-[75vh] w-auto object-contain rounded-2xl"
              style={{ animation: 'scaleIn 0.6s ease-out forwards' }}
            />
            <div className="mt-6 text-center">
              <h3 className="font-display text-3xl text-cream-50 mb-2">
                {currentPhoto.title}
              </h3>
              <p className="text-cream-300 max-w-xl font-light leading-relaxed mb-4">
                {currentPhoto.description}
              </p>
              <div className="flex items-center justify-center gap-6 text-[10px] tracking-[0.25em] uppercase text-cream-400">
                <span className="flex items-center gap-2">
                  <Tag size={14} /> {currentPhoto.category}
                </span>
                <span className="flex items-center gap-2">
                  <Calendar size={14} /> {currentPhoto.year}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              nextPhoto();
            }}
            className="absolute right-4 md:right-8 text-cream-200 hover:text-cream-50 transition-colors p-2 z-10"
            aria-label="Další"
          >
            <ChevronRight size={40} />
          </button>

          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-[10px] tracking-[0.3em] uppercase text-cream-500">
            {String(lightbox + 1).padStart(2, '0')} / {String(preview.length).padStart(2, '0')}
          </div>
        </div>
      )}
    </section>
  );
}
