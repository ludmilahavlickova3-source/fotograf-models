import { useState, useMemo } from 'react';
import { photos, type Photo } from '@/data/photos';
import { useReveal } from '@/hooks/useReveal';
import { X, ChevronLeft, ChevronRight, Calendar, Tag, ArrowLeft } from 'lucide-react';

const categories = ['Vše', 'Portrét', 'Editorial', 'Detail', 'Koncept', 'Krajina'];

const bentoSpans = [
  'col-span-2 row-span-2',
  'col-span-1 row-span-1',
  'col-span-1 row-span-1',
  'col-span-1 row-span-2',
  'col-span-2 row-span-1',
  'col-span-1 row-span-1',
  'col-span-1 row-span-1',
  'col-span-2 row-span-2',
  'col-span-1 row-span-1',
  'col-span-1 row-span-2',
  'col-span-2 row-span-1',
  'col-span-1 row-span-1',
];

export default function GalleryPage({ onNavigateHome }: { onNavigateHome: () => void }) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const [filter, setFilter] = useState('Vše');
  const [lightbox, setLightbox] = useState<number | null>(null);

  const filtered = useMemo(() => {
    if (filter === 'Vše') return photos;
    return photos.filter((p) => p.category === filter);
  }, [filter]);

  const openLightbox = (index: number) => setLightbox(index);
  const closeLightbox = () => setLightbox(null);
  const nextPhoto = () =>
    setLightbox((prev) =>
      prev === null ? null : (prev + 1) % filtered.length
    );
  const prevPhoto = () =>
    setLightbox((prev) =>
      prev === null ? null : (prev - 1 + filtered.length) % filtered.length
    );

  const currentPhoto: Photo | null =
    lightbox !== null ? filtered[lightbox] : null;

  return (
    <div className="min-h-screen bg-cream-50">
      {/* Header with back button */}
      <div className="pt-28 pb-8 px-6 md:px-12">
        <div className="max-w-[1600px] mx-auto">
          <button
            onClick={onNavigateHome}
            className="inline-flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-cream-600 hover:text-cream-950 transition-colors duration-500 mb-6 group"
          >
            <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform duration-300" />
            Zpět na hlavní stránku
          </button>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <p className="section-label mb-3">Kompletní sbírka</p>
              <h1 className="font-display text-5xl md:text-7xl text-cream-950 tracking-tight">
                Galerie
              </h1>
            </div>
            <p className="text-cream-600 max-w-sm font-light leading-relaxed">
              Všechny snímky, které mám rád. Filtrujte si, nebo se projděte celé.
            </p>
          </div>
        </div>
      </div>

      {/* Category filter */}
      <div className="px-6 md:px-12 mb-10">
        <div className="max-w-[1600px] mx-auto flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-2 text-[10px] tracking-[0.2em] uppercase rounded-full transition-all duration-500 ${
                filter === cat
                  ? 'bg-cream-950 text-cream-50'
                  : 'bg-cream-100 text-cream-600 hover:bg-cream-200 hover:text-cream-900 border border-cream-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Full bento grid */}
      <div
        ref={ref}
        className={`px-6 md:px-12 pb-20 reveal ${visible ? 'visible' : ''}`}
      >
        <div className="max-w-[1600px] mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[200px] md:auto-rows-[250px] gap-3 md:gap-4">
            {filtered.map((photo, i) => (
              <div
                key={photo.id}
                onClick={() => openLightbox(i)}
                className={`gallery-card group ${bentoSpans[i % bentoSpans.length]} ${
                  visible ? 'reveal visible' : 'reveal'
                }`}
                style={{ transitionDelay: `${(i % 8) * 0.06}s` }}
              >
                <div className={`w-full h-full ${!visible ? 'img-shimmer' : ''}`}>
                  <img
                    src={photo.src}
                    alt={photo.title}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="overlay" />
                <div className="meta">
                  <p className="text-[9px] tracking-[0.3em] uppercase text-gold-300 mb-1">
                    {photo.category} · {photo.year}
                  </p>
                  <h3 className="font-display text-xl md:text-2xl text-cream-50">
                    {photo.title}
                  </h3>
                </div>
                <div className="absolute top-3 right-3 font-display text-xs text-cream-50/0 group-hover:text-cream-50/50 transition-all duration-500">
                  {String(i + 1).padStart(2, '0')}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox !== null && currentPhoto && (
        <div
          className="fixed inset-0 z-[100] lightbox-backdrop bg-cream-950/90 flex items-center justify-center p-4 md:p-12"
          style={{ animation: 'fadeIn 0.4s ease-out forwards' }}
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 text-cream-200 hover:text-cream-50 transition-colors p-2 z-10"
            aria-label="Zavřít"
          >
            <X size={32} />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              prevPhoto();
            }}
            className="absolute left-4 md:left-8 text-cream-200 hover:text-cream-50 transition-colors p-2 z-10"
            aria-label="Předchozí"
          >
            <ChevronLeft size={40} />
          </button>

          <div
            className="max-w-4xl w-full flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
            style={{ animation: 'scaleIn 0.5s ease-out forwards' }}
          >
            <img
              src={currentPhoto.src}
              alt={currentPhoto.title}
              className="max-h-[75vh] w-auto object-contain rounded-2xl"
              style={{ animation: 'scaleIn 0.6s ease-out forwards' }}
            />
            <div className="mt-6 text-center">
              <h3 className="font-display text-3xl text-cream-50 mb-2">
                {currentPhoto.title}
              </h3>
              <p className="text-cream-300 max-w-xl font-light leading-relaxed mb-4">
                {currentPhoto.description}
              </p>
              <div className="flex items-center justify-center gap-6 text-[10px] tracking-[0.25em] uppercase text-cream-400">
                <span className="flex items-center gap-2">
                  <Tag size={14} /> {currentPhoto.category}
                </span>
                <span className="flex items-center gap-2">
                  <Calendar size={14} /> {currentPhoto.year}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              nextPhoto();
            }}
            className="absolute right-4 md:right-8 text-cream-200 hover:text-cream-50 transition-colors p-2 z-10"
            aria-label="Další"
          >
            <ChevronRight size={40} />
          </button>

          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-[10px] tracking-[0.3em] uppercase text-cream-500">
            {String(lightbox + 1).padStart(2, '0')} / {String(filtered.length).padStart(2, '0')}
          </div>
        </div>
      )}
    </div>
  );
}
