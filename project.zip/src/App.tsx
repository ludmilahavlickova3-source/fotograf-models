import { useState } from 'react';
import Loader from '@/components/Loader';
import CustomCursor from '@/components/CustomCursor';
import GrainOverlay from '@/components/GrainOverlay';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Marquee from '@/components/Marquee';
import Gallery from '@/components/Gallery';
import FeaturedWork from '@/components/FeaturedWork';
import About from '@/components/About';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import GalleryPage from '@/components/GalleryPage';
import { useRouter } from '@/hooks/useRouter';

function App() {
  const [loaded, setLoaded] = useState(false);
  const { route, navigate } = useRouter();

  return (
    <>
      <Loader onDone={() => setLoaded(true)} />
      <CustomCursor />
      <GrainOverlay />
      <div
        className={`min-h-screen bg-cream-50 text-cream-950 transition-opacity duration-1000 ${
          loaded ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <Navbar route={route} onNavigate={navigate} />
        <main>
          {route === 'home' ? (
            <>
              <Hero />
              <Marquee />
              <Gallery onNavigateGallery={() => navigate('gallery')} />
              <FeaturedWork />
              <About />
              <Contact />
            </>
          ) : (
            <GalleryPage onNavigateHome={() => navigate('home')} />
          )}
        </main>
        <Footer />
      </div>
    </>
  );
}

export default App;
