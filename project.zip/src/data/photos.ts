export interface Photo {
  id: string;
  src: string;
  title: string;
  category: string;
  year: string;
  description: string;
}

export const photos: Photo[] = [
  {
    id: 'p1',
    src: '/images/p1.jpg',
    title: 'Západ',
    category: 'Editorial',
    year: '2024',
    description: 'Světlo západu slunce na bílém svetru. Jednoduchý moment, který řekne víc než póza.',
  },
  {
    id: 'p2',
    src: '/images/p2.jpg',
    title: 'Červeň',
    category: 'Portrét',
    year: '2024',
    description: 'Červený svetr v teplém světle lampy. Chtěl jsem zachytit ten pocit, když se člověk cítí doma.',
  },
  {
    id: 'p3',
    src: '/images/p3.jpg',
    title: 'Lampa',
    category: 'Editorial',
    year: '2023',
    description: 'Stará lampa v rohu místnosti. Někdy stačí jedno světlo a zbytek nechat ve stínu.',
  },
  {
    id: 'p4',
    src: '/images/p4.jpg',
    title: 'Pohled',
    category: 'Portrét',
    year: '2024',
    description: 'Dívá se přímo do objektivu. Žádná póza, žádný úsměv na objednávku. Prostě ona.',
  },
  {
    id: 'p5',
    src: '/images/p5.jpg',
    title: 'Baret',
    category: 'Editorial',
    year: '2024',
    description: 'Zrzavé vlasy a baret. Odpoledne na gauči, když už nic neříkáme a fotka vznikne sama.',
  },
  {
    id: 'p6',
    src: '/images/p6.jpg',
    title: 'Slunce',
    category: 'Krajina',
    year: '2023',
    description: 'Pole za Prahou, léto, vítr ve vlasech. Šli jsme ven bez plánu a vyšlo to nejlépe.',
  },
  {
    id: 'p7',
    src: '/images/p7.jpg',
    title: 'Soumrak',
    category: 'Editorial',
    year: '2024',
    description: 'Poslední světlo dne na tváři. Máme na to tak dvacet minut, pak je tma.',
  },
  {
    id: 'p8',
    src: '/images/p8.jpg',
    title: 'Květina',
    category: 'Koncept',
    year: '2024',
    description: 'Květinová čelenka. Trochu retro, trochu hra. Ne každá fotka musí být vážná.',
  },
  {
    id: 'p9',
    src: '/images/p9.jpg',
    title: 'Židle',
    category: 'Editorial',
    year: '2023',
    description: 'Dřevěná židle v pronajatém studiu. Někdy je nejlepší rekvizita ta nejjednodušší.',
  },
  {
    id: 'p10',
    src: '/images/p10.jpg',
    title: 'Oranž',
    category: 'Portrét',
    year: '2024',
    description: 'Oranžový gel na okně. Barva mění úplně všechno, zkouším to pořád.',
  },
  {
    id: 'p11',
    src: '/images/p11.jpg',
    title: 'Odraz',
    category: 'Portrét',
    year: '2023',
    description: 'Profil v odrazu skla. Dva pohledy na jednu osobu v jednom snímku.',
  },
  {
    id: 'p12',
    src: '/images/p12.jpg',
    title: 'Růže',
    category: 'Koncept',
    year: '2024',
    description: 'Růže pod závojem. Romantika, ano, ale hlavně mě zajímalo, co dělá světlo s látkou.',
  },
  {
    id: 'p13',
    src: '/images/p13.jpg',
    title: 'Bruneta',
    category: 'Detail',
    year: '2024',
    description: 'Zblízka. Dost blízko na to, aby si člověk všiml pih a jizviček. To mě zajímá víc než hladká kůže.',
  },
  {
    id: 'p14',
    src: '/images/p14.jpg',
    title: 'Klid',
    category: 'Detail',
    year: '2024',
    description: 'Zavřené oči a měkké světlo z okna. Klid, který nemůžete objednat.',
  },
  {
    id: 'p15',
    src: '/images/p15.jpg',
    title: 'Oči',
    category: 'Detail',
    year: '2023',
    description: 'Šedé oči, žádný makeup. Fotka vznikla mezi dvěma záběry, když si odpočívala.',
  },
  {
    id: 'p16',
    src: '/images/p16.jpg',
    title: 'Náhrdelník',
    category: 'Portrét',
    year: '2024',
    description: 'Náhrdelník po babičce. Nosila ho na focení a já jsem věděl, že ho musím dostat do záběru.',
  },
  {
    id: 'p17',
    src: '/images/p17.jpg',
    title: 'Zavřené',
    category: 'Detail',
    year: '2024',
    description: 'Podsvícení ze závěsu. Světlo, které obchází místnost, než dopadne na obličej.',
  },
  {
    id: 'p18',
    src: '/images/p18.jpg',
    title: 'Béžová',
    category: 'Portrét',
    year: '2023',
    description: 'Béžová stěna, bílé světlo, žádná přesná představa. Někdy fotím zhruba a čekám, co se stane.',
  },
  {
    id: 'p19',
    src: '/images/p19.jpg',
    title: 'Černé',
    category: 'Editorial',
    year: '2024',
    description: 'Černé šaty, čistá stěna. Modelka se cítila dobře a to je na snímku vidět.',
  },
  {
    id: 'p20',
    src: '/images/p20.jpg',
    title: 'Sequiny',
    category: 'Editorial',
    year: '2024',
    description: 'Třpytivé šaty. Chtěl jsem, aby se ty sequiny chytly blesku. Trvalo to tři pokusy.',
  },
  {
    id: 'p21',
    src: '/images/p21.jpg',
    title: 'Ramena',
    category: 'Portrét',
    year: '2023',
    description: 'Otevřená ramena, boční světlo. Jeden z těch snímků, kdy víte hned, že je hotový.',
  },
  {
    id: 'p22',
    src: '/images/p22.jpg',
    title: 'Záda',
    category: 'Detail',
    year: '2024',
    description: 'Otevřená záda. Stojí za to občas fotit něco jiného než obličej.',
  },
  {
    id: 'p23',
    src: '/images/p23.jpg',
    title: 'Klobouk',
    category: 'Editorial',
    year: '2024',
    description: 'Černý klobouk ze starého kostýmu. Nosí ho na každém focení, takže se s ním už fotí sama.',
  },
  {
    id: 'p24',
    src: '/images/p24.jpg',
    title: 'Makeup',
    category: 'Detail',
    year: '2024',
    description: 'Makeup studio. Chtěl jsem ukázat ten proces, nejen výsledek. Focení začíná už tam.',
  },
];

export const heroImages = [
  '/images/hero1.jpg',
  '/images/hero2.jpg',
  '/images/hero3.jpg',
  '/images/hero4.jpg',
  '/images/hero5.jpg',
];

export const aboutImage = '/images/about.jpg';

export const featuredImage = '/images/featured.jpg';

export const splitLeftImage = '/images/split-left.jpg';
export const splitRightImage = '/images/split-right.jpg';

export const landscapeImage1 = '/images/landscape1.jpg';
export const landscapeImage2 = '/images/landscape2.jpg';

export const quotes = [
  {
    text: 'Nefotografuji krásu. Hledám moment, kdy člověk přestane předstírat.',
    author: 'Robert Rot',
  },
  {
    text: 'Nejlepší snímky vznikají, když už nic neplánujeme.',
    author: 'Robert Rot',
  },
  {
    text: 'Světlo je všechno. Zbytek je jen trpělivost.',
    author: 'Robert Rot',
  },
];

export const marqueeWords = [
  'Světlo',
  'Stín',
  'Ticho',
  'Portrét',
  'Žena',
  'Moment',
  'Příběh',
  'Pohled',
  'Krajina',
  'Detail',
];

export const stats = [
  { value: 20, suffix: '+', label: 'Let praxe' },
  { value: 14, suffix: '', label: 'Výstav' },
  { value: 6, suffix: '', label: 'Publikací' },
  { value: 200, suffix: '+', label: 'Modelů' },
];
